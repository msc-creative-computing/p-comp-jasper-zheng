[PDF version](https://github.com/msc-creative-computing/p-comp-jasper-zheng/blob/main/week_final/Presentation_Board.pdf)  

<img src="InformationBoard-01.jpg">    

[https://github.com/msc-creative-computing/p-comp-jasper-zheng/tree/main/week_final](https://github.com/msc-creative-computing/p-comp-jasper-zheng/tree/main/week_final)  

<img src="InformationBoard-02.jpg">    

[https://youtu.be/vGd-JQdAmYI](https://youtu.be/vGd-JQdAmYI)   

<img src="InformationBoard-03.jpg">    

[https://github.com/sensorium/Mozzi](https://github.com/sensorium/Mozzi)  

[https://learn.adafruit.com/adafruit-mpr121-12-key-capacitive-touch-sensor-breakout-tutorial](https://learn.adafruit.com/adafruit-mpr121-12-key-capacitive-touch-sensor-breakout-tutorial)    

<img src="InformationBoard-04.jpg">    
<img src="InformationBoard-05.jpg">    
<img src="InformationBoard-06.jpg">    

Video 1   
[https://youtu.be/vGd-JQdAmYI](https://youtu.be/vGd-JQdAmYI)  

Video 2   
[https://youtu.be/jQ1evAxYSqI](https://youtu.be/jQ1evAxYSqI)  

Github Repositories (Codes, and other documenntations)  
[https://github.com/msc-creative-computing/p-comp-jasper-zheng/tree/main/week_final](https://github.com/msc-creative-computing/p-comp-jasper-zheng/tree/main/week_final)  
