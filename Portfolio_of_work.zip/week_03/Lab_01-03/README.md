# Week 3 Labs 1-3 Walkthrough

### Lab 01: PWM  

![lab01](https://github.com/msc-creative-computing/p-comp-jasper-zheng/blob/main/week_03/Lab_01-03/pcomp_week03_lab01.gif?raw=true)  


### Lab 02: Voltage Dividers

![lab02](https://github.com/msc-creative-computing/p-comp-jasper-zheng/blob/main/week_03/Lab_01-03/pcomp_week03_lab02.gif?raw=true)  


### Lab 03: Dark detecting Circuit for pumpkins   

![lab03](https://github.com/msc-creative-computing/p-comp-jasper-zheng/blob/main/week_03/Lab_01-03/pcomp_week03_lab03.gif?raw=true)  
